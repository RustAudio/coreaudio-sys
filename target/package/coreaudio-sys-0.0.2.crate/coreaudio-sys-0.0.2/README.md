
# coreaudio-sys

Raw bindings to Apple's Core Audio API for OS X and iOS generated using [rust-bindgen](https://github.com/crabtw/rust-bindgen) for use with [coreaudio-rs](https://github.com/RustAudio/coreaudio-rs).

